package Util;

import CoreLogic.ReadTestCaseData_Implementation;

public class TestBaseClass {

    public static ReadTestCaseData_Implementation testdata= new ReadTestCaseData_Implementation();

}
